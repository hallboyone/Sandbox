% Script to simulate a cart carrying an inverted pendulum. The cart is
% controlled by a P controller (defined in the function controlInput and
% it tries to drive the pendulum's angle to 0.

%% Setup System
global m_b m_c g l Kp Kd;
m_b = 1;
m_c = 10;
g = 9.81;
l = 2;
Kp = 363;
Kd = 80;

%Initial conditions
z0 = [0; 0; .25; 0]; %[x, v, theta, omega]

%% Simulate with actual dynamics
[times, z] = ode45(@cart_dyn, [0, 20], z0);

%Only keep results up until the system settled
plot_lim = find(abs(z(:,3)) > 0.001*abs(z0(3)), 1, 'last');
if ~isempty(plot_lim)
    times = times(1:plot_lim);
    z = z(1:plot_lim, :);
end

%% Plot simulation (if desired) 
if true
    next_time = 0;
    %Comment to see the cart move. Uncomment to lock cart to origin
    z(:,1) = 0;
    times = round(times, 3);
    for t = 1:numel(times)
        if (times(t) < next_time)
            continue;
        end
        next_time = next_time + 0.05;
        center = ceil((z(t, 1)-5)/10);
        plot([-5, 5] + center*10, [0,0], 'k-', 'LineWidth', 2);
        hold on
        plot([z(t, 1)-.5, z(t, 1)+.5], [0, 0], 'r-', 'LineWidth', 2);
        plot([z(t, 1), z(t, 1)-l*sin(z(t, 3))], [0, l*cos(z(t, 3))], 'g-', 'LineWidth', 2);
        xlim([-5, 5] + center*10);
        ylim([-5, 5]);
        title("Time: " + times(t) + " sec");
        hold off
        drawnow
    end
end

%% Make linearized system
a = g * (m_b + m_c) / (m_c * l);
b = 1 / (m_c * l);
sys = ss([0 1; a - Kp*b, -Kd*b], [], [1 0], 0);

%% Plot resulting response
plot(times, z(:,3), 'r-')
hold on
initial(sys, z0(3:4));
legend("Nonlinear Response", "Linear Response");

%% Cart Dynamics
function dzdt = cart_dyn(t, z)
global m_b m_c g l;

cos_theta = cos(z(3));
sin_theta = sin(z(3));

F = controlInput(z, t);

x_ddt = (m_b*g*sin_theta*cos_theta - m_b*l*z(4)^2*sin_theta + F)/(m_c + m_b*(1-cos_theta^2));

dzdt = [z(2);
        x_ddt;
        z(4);
        g/l*sin_theta + 1/l*x_ddt*cos_theta];
end

%% Controller
function F = controlInput(z, ~)
global Kp Kd;
err = -z;
F = Kp*err(3) + Kd*err(4);
end