% Script to simulate a cart carrying an inverted pendulum. The cart is
% controlled by a PID controller (defined in the function controlInput and
% it tries to track the reference angle defined in the function refTheta

%% Setup System
global m_b m_c g l;
m_b = 1;
m_c = 10;
g = 9.81;
l = 2;

%Initial conditions
z0 = [0; 0; 0; 0]; %[x, v, theta, omega]

%% Simulate with actual dynamics
[times, z] = ode45(@cart_dyn, [0, 20], z0);

%% Plot simulation (if desired) 
if true
    next_time = 0;
    %Comment to see the cart move. Uncomment to lock cart to origin
    z(:,1) = 0;
    times = round(times, 3);
    for t = 1:numel(times)
        if (times(t) < next_time)
            continue;
        end
        next_time = next_time + 0.05;
        
        center = ceil((z(t, 1)-5)/10);
        
        plot([-5, 5] + center*10, [0,0], 'k-', 'LineWidth', 2);
        hold on
        plot([z(t, 1)-.5, z(t, 1)+.5], [0, 0], 'r-', 'LineWidth', 2);
        plot([z(t, 1), z(t, 1)-l*sin(z(t, 3))], [0, l*cos(z(t, 3))], 'g-', 'LineWidth', 2);
        xlim([-5, 5] + center*10);
        ylim([-5, 5]);
        title("Time: " + times(t) + " sec");
        hold off
        drawnow
    end
end

%% Plot resulting response
plot(times, z(:,3), 'r-')
hold on
plot(times, refTheta(times), 'k:');

%% Cart Dynamics
function dzdt = cart_dyn(t, z)
global m_b m_c g l;

cos_theta = cos(z(3));
sin_theta = sin(z(3));

F = controlInput(z, t);

x_ddt = (m_b*g*sin_theta*cos_theta - m_b*l*z(4)^2*sin_theta + F)/(m_c + m_b*(1-cos_theta^2));

dzdt = [z(2);
        x_ddt;
        z(4);
        g/l*sin_theta + 1/l*x_ddt*cos_theta];
end

%% Controller
function F = controlInput(z, t)
err = refTheta(t) - z;

%Sum of errors (for integral gain)
persistent error_sum
if isempty(error_sum) || t<0.05
    error_sum = err(3);
else
    error_sum = error_sum + err(3);
end

%PID controller gains
K = [3630, 15, 800];

F = K(1)*err(3) + K(2)*error_sum + K(3)*err(4);
end

%% Reference position
function target = refTheta(t)
target = 0.25 * sin(2*t);
end