global m_b m_c g l;
m_b = 1;
m_c = 10;
g = 9.81;
l = 2;

z0 = [0; 0; .1; 0]; %[x, v, a, theta, omega, alpha]

%Simulate with true dynamics
[times, z] = ode45(@cart_dyn, [0, 20], z0);

plot_lim = find(abs(z(:,3)) > 0.001*abs(z0(3)), 1, 'last');
if ~isempty(plot_lim)
    times = times(1:plot_lim);
    z = z(1:plot_lim, :);
end

%Plot simulation
if true
    next_time = 0;
    %Comment to see the cart move. Uncomment to lock cart to origin
    z(:,1) = 0;
    times = round(times, 3);
    for t = 1:numel(times)
        if (times(t) < next_time)
            continue;
        end
        next_time = next_time + 0.05;
        
        center = ceil((z(t, 1)-5)/10);
        
        plot([-5, 5] + center*10, [0,0], 'k-', 'LineWidth', 2);
        hold on
        plot([z(t, 1)-.5, z(t, 1)+.5], [0, 0], 'r-', 'LineWidth', 2);
        plot([z(t, 1), z(t, 1)-l*sin(z(t, 3))], [0, l*cos(z(t, 3))], 'g-', 'LineWidth', 2);
        xlim([-5, 5] + center*10);
        ylim([-5, 5]);
        title("Time: " + times(t) + " sec");
        hold off
        drawnow
    end
end

%Make linearized system
a = g * (m_b + m_c) / (m_c * l);
b = 1 / (m_c * l);
w_n = 3.5714;
zeta = 0.56;
Kp = (w_n^2+a)/b;
Kd = 2*zeta*w_n/b;
sys = ss([0 1; a - Kp*b, -Kd*b], [], [1 0], 0);

plot(times, z(:,3), 'r-')
hold on
plot([0, times(end)], [0,0], 'k:');
initial(sys, z0(3:4));

function dzdt = cart_dyn(~, z)
global m_b m_c g l;
cos_theta = cos(z(3));
sin_theta = sin(z(3));

F = controlInput(-z);

x_ddt = (m_b*g*sin_theta*cos_theta - m_b*l*z(4)^2*sin_theta + F)/(m_c + m_b*(1-cos_theta^2));

%Add damping
%x_ddt = x_ddt - 0.01*z(2)^2*sign(z(2));

dzdt = [z(2);
        x_ddt;
        z(4);
        g/l*sin_theta + 1/l*x_ddt*cos_theta];
    
%dzdt = dzdt + 5*(0.5 - rand(4,1));
end

function F = controlInput(err)
%Sum of errors (for itegral gain)
persistent error_sum
if isempty(error_sum)
    error_sum = err(3);
else
    error_sum = error_sum + err(3);
end

%P Controller - Fast
K = [15000, 0, 0];
%P Controller - Slow
%K = [-120, 0, 0];
% 
%PD Controller
K = [500, 0, 60];

K = [363, 0, 80];
F = K(1)*err(3) + K(2)*error_sum + K(3)*err(4);
end