% Script to simulate a cart carrying an inverted pendulum. The cart is
% uncontrolled so the response is unstable

%% Setup System
global m_b m_c g l;
m_b = 1;
m_c = 10;
g = 9.81;
l = 2.5;

%Initial conditions
z0 = [0; 0; .1; 0]; %[x, v, theta, omega]

%% Simulate with actual dynamics
[times, z] = ode45(@cart_dyn, [0, 20], z0);

%% Plot simulation (if desired) 
if true
    %Comment to see the cart move. Uncomment to lock cart to origin
    %z(:,1) = 0;
    times = round(times, 3);
    next_time = 0;
    for t = 1:numel(times)
        %Only plot times further than 0.1 sec apart
        if (times(t) < next_time)
            continue;
        else
            next_time = times(t) + 0.1;
        end
        
        %Plot the ground plance
        center = ceil((z(t, 1)-5)/10);
        plot([-5, 5] + center*10, [0,0], 'k-', 'LineWidth', 2);
        hold on
        
        %Plot the cart
        plot([z(t, 1)-.5, z(t, 1)+.5], [0, 0], 'r-', 'LineWidth', 2);
        
        %Plot the pendulum
        plot([z(t, 1), z(t, 1)-l*sin(z(t, 3))], [0, l*cos(z(t, 3))], 'g-', 'LineWidth', 2);
        xlim([-5, 5] + center*10);
        ylim([-5, 5]);
        title("Time: " + times(t) + " sec");
        hold off
        drawnow
    end
end

%% Plot resulting response
plot(times, z(:,3), 'r-')
hold on
plot([0, times(end)], [0,0], 'k:');

%% Cart Dynamics
function dzdt = cart_dyn(~, z)
global m_b m_c g l;
cos_theta = cos(z(3));
sin_theta = sin(z(3));

x_ddt = (m_b*g*sin_theta*cos_theta - m_b*l*z(4)^2*sin_theta)/(m_c + m_b*(1-cos_theta^2));

%Add damping for numerical stability
x_ddt = x_ddt - 0.01*z(2)^2*sign(z(2));

dzdt = [z(2);
    x_ddt;
    z(4);
    g/l*sin_theta + 1/l*x_ddt*cos_theta];
end